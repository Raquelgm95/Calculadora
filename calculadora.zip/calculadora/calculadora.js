const txtOp1 = document.getElementById("op1")
const txtOperacion = document.getElementById("operacion")
const txtOp2 = document.getElementById("op2")
const btnCalcular = document.getElementById("calcular")
const pResultado = document.getElementById("resultado")

// Para que el boton calcular funcione //
// 1- Se pone el nombre de la constante "btnCalcular"
// 2- Se añade el .addEventListener que es un escuchador de evento para que sepa que tiene que hacer
// 3- Y dentro se añade el click para cuando pulse el boton y despues se pone la funcion que se llama calcular

btnCalcular.addEventListener('click', calcular)

// Funcionamiento calculadora //

function calcular() {
    const operacion = txtOperacion.value
    const op1 = parseFloat(txtOp1.value) //  pasefloat para que el string txt pase aa numero decimal
    const op2 = parseFloat(txtOp2.value)

    if( (operacion == "+" || operacion == "-" || operacion == "*" || operacion == "/") && !isNaN(op1) && !isNaN(op2) ){ 
        // !isNaN, se pone para que cuente que es un numero 
        let resultado;
        switch(operacion){
            case "+":
                resultado = op1 + op2
                break; // el break se pone para que realice la operacion y ya no haga mas, si no se pone jecuta todas las operaciones
            case "-":
                resultado = op1 - op2
                break;
            case "*":
                resultado = op1 * op2
                break;
            case "/":
                resultado = op1 / op2
                break;
        }
        pResultado.style = "color:green"
        pResultado.innerText = "=" + resultado
    }else {
        pResultado.style = "color:red"
        pResultado.innerText = "calculo imposible"
    }
}
